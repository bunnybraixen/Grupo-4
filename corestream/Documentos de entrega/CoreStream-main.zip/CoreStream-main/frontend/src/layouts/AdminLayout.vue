<!--
  Layout para sección de administración

  Proporciona navegación sidebar y estructura común para todas las vistas admin.
-->
<template>
  <div class="flex h-screen bg-[var(--bg-app)]">
    <!-- Sidebar -->
    <aside class="w-64 bg-[var(--bg-sidebar)] border-r border-[var(--border-subtle)]">
      <nav class="p-6 space-y-4">
        <h2 class="font-bold text-lg text-[var(--text-primary)] mb-6">
          {{ t('nav.administration') }}
        </h2>

        <router-link
          to="/admin/builder"
          class="block px-4 py-2 rounded-lg text-[var(--text-secondary)] hover:bg-[var(--bg-panel)]"
        >
          {{ t('nav.builder') }}
        </router-link>

        <router-link
          to="/admin/analytics"
          class="block px-4 py-2 rounded-lg text-[var(--text-secondary)] hover:bg-[var(--bg-panel)]"
        >
          {{ t('nav.analytics') }}
        </router-link>

        <router-link
          to="/admin/code-docs"
          class="block px-4 py-2 rounded-lg text-[var(--text-secondary)] hover:bg-[var(--bg-panel)]"
        >
          {{ t('nav.documentation') }}
        </router-link>

        <router-link
          to="/admin/team"
          class="block px-4 py-2 rounded-lg text-[var(--text-secondary)] hover:bg-[var(--bg-panel)]"
        >
          {{ t('nav.team') }}
        </router-link>

        <router-link
          to="/admin/support"
          class="block px-4 py-2 rounded-lg text-[var(--text-secondary)] hover:bg-[var(--bg-panel)]"
        >
          {{ t('nav.support') }}
        </router-link>

      </nav>
    </aside>

    <!-- Contenido principal -->
    <main class="flex-1 overflow-auto">
      <div class="flex items-center justify-between px-6 py-4 border-b border-[var(--border-subtle)] bg-[color-mix(in_srgb,var(--bg-header)_80%,transparent)] backdrop-blur">
        <div>
          <p class="text-xs uppercase tracking-[0.2em] text-[var(--text-muted)]">CoreStream</p>
          <h1 class="text-lg font-semibold text-[var(--text-primary)]">{{ t('nav.adminPanel') }}</h1>
        </div>
        <button
          type="button"
          @click="logout"
          class="px-4 py-2 rounded-lg bg-[var(--priority-urg-bg)] text-white hover:opacity-90 transition-colors"
        >
          {{ t('header.logout') }}
        </button>
      </div>
      <router-view />
    </main>
  </div>
</template>

<script setup lang="ts">
/**
 * AdminLayout - Componente de estructura para vistas de administración
 */
import { useRouter } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { useAuthStore } from '@/stores'

const router = useRouter()
const authStore = useAuthStore()
const { t } = useI18n()

const logout = async () => {
  await authStore.logout()
  await router.push('/login')
}
</script>
